create definer = `339575`@`%` view classementpilote as
select `f1`.`pilote`.`id`                                        AS `id`,
       `f1`.`pilote`.`nom`                                       AS `nom`,
       `f1`.`pilote`.`idPays`                                    AS `idPays`,
       `f1`.`pilote`.`idEcurie`                                  AS `idEcurie`,
       (select ifnull(sum(`f1`.`resultat`.`point`), 0)
        from `f1`.`resultat`
        where (`f1`.`resultat`.`idPilote` = `f1`.`pilote`.`id`)) AS `point`,
       (select (count(0) + 1)
        from (select ifnull(sum(`f1`.`resultat`.`point`), 0) AS `total_points`
              from `f1`.`resultat`
              group by `f1`.`resultat`.`idPilote`) `p`
        where (`p`.`total_points` > `point`))                    AS `place`
from `f1`.`pilote`
order by (select ifnull(sum(`f1`.`resultat`.`point`), 0)
          from `f1`.`resultat`
          where (`f1`.`resultat`.`idPilote` = `f1`.`pilote`.`id`)) desc;

