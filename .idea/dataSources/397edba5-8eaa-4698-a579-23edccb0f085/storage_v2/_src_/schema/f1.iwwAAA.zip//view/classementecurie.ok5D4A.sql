create definer = `339575`@`%` view classementecurie as
select `f1`.`ecurie`.`id`                            AS `id`,
       `f1`.`ecurie`.`nom`                           AS `nom`,
       `f1`.`ecurie`.`idPays`                        AS `idPays`,
       (select sum(`f1`.`classementpilote`.`point`)
        from `f1`.`classementpilote`
        where (`f1`.`classementpilote`.`idEcurie` = `f1`.`ecurie`.`id`)
        group by `f1`.`classementpilote`.`idEcurie`) AS `point`,
       (select (count(0) + 1)
        from (select sum(`f1`.`classementpilote`.`point`) AS `total_points`
              from `f1`.`classementpilote`
              group by `f1`.`classementpilote`.`idEcurie`) `p`
        where (`p`.`total_points` > `point`))        AS `place`
from `f1`.`ecurie`
order by (select sum(`f1`.`classementpilote`.`point`)
          from `f1`.`classementpilote`
          where (`f1`.`classementpilote`.`idEcurie` = `f1`.`ecurie`.`id`)
          group by `f1`.`classementpilote`.`idEcurie`) desc;

